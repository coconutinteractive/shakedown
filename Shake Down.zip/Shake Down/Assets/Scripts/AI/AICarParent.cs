﻿using UnityEngine;
using System.Collections;

public class AICarParent : MonoBehaviour 
{
	[SerializeField] protected float maxSpeed = 0.0f, currentSpeed = 0.0f, accelerationTime = 0.0f;
	[SerializeField] protected float triggerRefusalChance = 0.0f;
	[SerializeField] protected GameObject currentCamPoint = null;
	protected Rigidbody myRigidbody = null;

	private void Start()
	{
		myRigidbody = GetComponent<Rigidbody> ();
		currentSpeed = maxSpeed;
	}

	private void FixedUpdate()
	{
		myRigidbody.velocity = transform.right * currentSpeed;
	}

	private void OnTriggerEnter(Collider c)
	{
		if(c.CompareTag("Street Corner Trigger"))
		{
			StartCoroutine(TurnCorner(c.gameObject));
		}
	}

	private IEnumerator TurnCorner(GameObject _turnTriggerObj)
	{
		currentCamPoint = _turnTriggerObj.GetComponent<StreetCornerTrigger>().GetNewCamPoint(currentCamPoint);


		yield return null;
	}

}
