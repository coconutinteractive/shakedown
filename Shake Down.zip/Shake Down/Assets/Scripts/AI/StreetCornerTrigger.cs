﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

public class StreetCornerTrigger : MonoBehaviour 
{
	[SerializeField] private List<GameObject> cameraPoints = new List<GameObject>();

	public GameObject GetNewCamPoint(GameObject _curCamPoint)
	{
		List<GameObject> availableCamPoints = new List<GameObject> ();
		foreach (GameObject curCamPoint in cameraPoints)
		{
			if(curCamPoint != _curCamPoint)
				availableCamPoints.Add(curCamPoint);
		}

		return availableCamPoints[Random.Range (0, availableCamPoints.Count)];
	}
}
